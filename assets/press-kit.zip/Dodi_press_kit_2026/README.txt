DODI - PRESS KIT (September 2026)

Artist name: Dodi
Based in: Stockholm, Sweden
Genre: minimal / microhouse

CONTENTS
photos/web-2048px/    3 press photos, sRGB JPEG, long side 2048 px. Use for web, socials, RA.
photos/print-4000px/  Same 3 photos, sRGB JPEG, long side 4000 px. Use for print (posters, flyers).
bio-en.txt            Short and long bio in English.
bio-sv.txt            Short and long bio in Swedish.
links.txt             Links and social handles.

PHOTO CREDIT (required on every use)
Photo: Albin Händig (albinhandig.se)

PHOTOS
186   landscape, black and white, arms crossed against concrete. Primary press shot.
736   landscape, colour, dusk on an empty lot.
1020  portrait, black and white, wide shot on a concrete wall. Atmospheric, works as a background.

TAGGING
Resident Advisor: ra.co/dj/dodi-sw
Instagram: @dodi.musik
Spotify: listed as "Dodi (SE)". There is another artist called Dodi on Spotify and Beatport, so please link this one.

CONTACT
Bookings: booking@dodi.fm
Everything else: hello@dodi.fm
EPK: https://dodi.fm
